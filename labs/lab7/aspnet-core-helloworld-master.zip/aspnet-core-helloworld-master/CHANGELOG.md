## May 16, 2016
- Update sample to use Dotnet CLI

## Feb 23, 2016
- Changed all references to ASP.Net 5 to say ASP.Net Core

## Nov 24, 2015
- Added changelog
